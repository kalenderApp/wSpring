<?php get_header(); ?>
<div id="main">
  <div id="left">
    <div class="logo">
      <a href="<?php bloginfo('url'); ?>"><img src="<?php bloginfo('template_url'); ?>/imgs/Shelf-Logo.png" alt="" /></a>
      <h1><a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a></h1>
    </div>
    <div class="desp">
      <h3><?php bloginfo('description'); ?></h3>
    </div>
    <div class="tips">
      <span>You can scroll the shelf using ← and → keys</span>
    </div>
    <?php 
	     $options = get_option('analytics_options');
    ?>
    <?php if(!$options['commentads']){
      	$ads = "";
      } else {
      	echo '<div class="google_ads">'.$options['commentads'].'</div>';
      	}
    ?>
  </div>
  
  
  
  
  
  
  
  <div id="right">
    <div class="comments">
      <ul>
        <li>
          <div class="author">
            <div class="pic">
              <img class="" src="imgs/avatar.jpg" />
            </div>
            <div class="name">
              <a href="#">大山</a>
            </div>
          </div>
          <div class="info">
            <div class="data">
              <span class="date">2011年07月19日</span><span class="action"><a href="#">回复</a> | <a href="#">引用</a></span>
            </div>
            <div class="clear"></div>
            <div class="content">
              One morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin
            </div>
          </div>
          <div class="clear"></div>
        </li>
        <li>
          <div class="author">
            <div class="pic">
              <img class="" src="imgs/avatar.jpg" />
            </div>
            <div class="name">
              <a href="#">大山</a>
            </div>
          </div>
          <div class="info">
            <div class="data">
              <span class="date">2011年07月19日</span><span class="action"><a href="#">回复</a> | <a href="#">引用</a></span>
            </div>
            <div class="clear"></div>
            <div class="content">
              One morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin
            </div>
          </div>
          <div class="clear"></div>
        </li>
        <li>
          <div class="author">
            <div class="pic">
              <img class="" src="imgs/admin.jpg" />
            </div>
            <div class="name">
              <a href="#">一米</a>
            </div>
          </div>
          <div class="info">
            <div class="data">
              <span class="date">2011年07月19日</span><span class="action"><a href="#">回复</a> | <a href="#">引用</a></span>
            </div>
            <div class="clear"></div>
            <div class="content">
              One morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin
            </div>
          </div>
          <div class="clear"></div>
        </li>
        
      </ul>
    </div>
    <div class="clear"></div>
    <div class="inputarea">
      <label for="username"><input type="text" value="昵称" required />昵称(必须)</label><br />
      <label for="email"><input type="email" value="E-mail" required />电子邮箱(必须)</label><br />
      <label for="website"><input type="website" value="网址" />网址</label><br />
      <textarea></textarea><br />
      <input class="submit" type="submit" value="发布(Ctrl+Enter)" />
    </div>
  </div>
  
  
  
  
  
  <div id="center">
    <div class="title">
      <h2>Dali exhibit coming to town</h2>
    </div>
    <div class="content">
      <p>
        One morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin. He lay on his armour-like back, and if he lifted his head a little he could see his brown belly, slightly domed and divided by arches into stiff sections. A collection of textile samples lay spread out on the table – Samsa was a travelling salesman – and above it there hung a picture that he had recently cut out of an illustrated magazine and housed in a nice, gilded frame. It showed a lady fitted out with a fur hat and fur boa who sat upright, raising a heavy fur muff that covered the whole of her lower arm towards the viewer. Gregor then turned to look out the window at the dull weather.
<img src="imgs/PhilMusArt-Dali-Figure-212x300.jpg" alt="" />
He must have tried it a hundred times, shut his eyes so that he wouldn’t have to look at the floundering legs.
Gregor then turned to look out the window at the dull weather. Drops of rain could be heard hitting the pane, which made him feel quite sad. “How about if I sleep a little bit longer and forget all this nonsense”, he thought, but that was something he was unable to do because he was used to sleeping on his right, and in his present state couldn’t get into that position. However hard he threw himself onto his right, he always rolled back to where he was.
      </p>
    </div>
    <div class="under">
      <span class="time">时间：</span><span>2011年7月22日</span><span class="categories">分类：</span><span><a href="#">视频</a></span><span class="tags">标签：</span><span><a href="#">搞笑</a>, <a href="#">视频</a>, <a href="#">80后</a></span>
    </div>
  </div>
</div>
<?php get_footer(); ?>