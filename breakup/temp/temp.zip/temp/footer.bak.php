<?php
			global $wpdb;
			$post_datetimes = $wpdb->get_row($wpdb->prepare("SELECT YEAR(min(post_date_gmt)) AS firstyear, YEAR(max(post_date_gmt)) AS lastyear FROM $wpdb->posts WHERE post_date_gmt > 1970"));
			if ($post_datetimes) {
				$firstpost_year = $post_datetimes->firstyear;
				$lastpost_year = $post_datetimes->lastyear;

				$copyright = __('Copyright &copy; ', 'inove') . $firstpost_year;
				if($firstpost_year != $lastpost_year) {
					$copyright .= '-'. $lastpost_year;
				}
				$copyright .= ' ';
			}
?>
<div id="footer">
  <div id="copyright">
    <span><a href="http://wordpress.org" target="_blank">WordPress</a></span><span><?php echo $copyright;  bloginfo('name'); ?></span><span>BreakUp 由 <a href="http://yimi.in" target="_blank">一米</a> 提供</span>
  </div>
  <div id="footermenu">
    <ul>
      <li>
      	<form action="<?php bloginfo('home'); ?>" method="get">
        	<input class="keywords" type="text" value="关键字" />
			<input class="search" type="submit" value="搜索" />
        </form>
      </li>
      <li>
        <input class="pagenum" type="text" value="页码" />
		<input class="go" type="button" value="转到" />
      </li>
    </ul>
  </div>
</div>
		<!-- 如果用户选择显示统计代码, 并且有代码, 则显示出来 -->
		<?php if($options['analytics'] && $options['analytics_content']) : ?>
			<?php echo($options['analytics_content']); ?>
		<?php endif; ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/script/js.dev.js"></script>
</body>
</html>