<?php get_header(); ?>
<div id="main">
  <div id="left">
    <div class="logo">
		<?php 
			//if($options['logo']){
				//$logo = $options['logo'];
				echo '<a href="'.bloginfo('url');.'"><img src="'.$logo.'" alt="'.bloginfo('name');.'" /></a>';	
			//}
		?>
      <h1><a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a></h1>
    </div>
    <div class="desp">
      <h3><?php bloginfo('description'); ?></h3>
    </div>
    <div class="tips">
      <!--<span>You can scroll the shelf using ← and → keys</span>-->
    </div>
  </div>
  
  
  
  
  
  
  
  <div id="right">
    <div class="comments">
      <!--<ul>-->
      	<?php if (have_posts()) : while (have_posts()) : the_post(); update_post_caches($posts); ?>
      	<?php
		    global $withcomments;
		    $withcomments = true;
		
		    // 包含评论模板文件，
		    comments_template("/comments.php");
		?>
		<?php endwhile; else : ?>
    	<?php endif; ?>
        <!--<li>
          <div class="author">
            <div class="pic">
              <img class="" src="imgs/avatar.jpg" />
            </div>
            <div class="name">
              <a href="#">大山</a>
            </div>
          </div>
          <div class="info">
            <div class="data">
              <span class="date">2011年07月19日</span><span class="action"><a href="#">回复</a> | <a href="#">引用</a></span>
            </div>
            <div class="clear"></div>
            <div class="content">
              One morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin
            </div>
          </div>
          <div class="clear"></div>
        </li>
        <li>
          <div class="author">
            <div class="pic">
              <img class="" src="imgs/avatar.jpg" />
            </div>
            <div class="name">
              <a href="#">大山</a>
            </div>
          </div>
          <div class="info">
            <div class="data">
              <span class="date">2011年07月19日</span><span class="action"><a href="#">回复</a> | <a href="#">引用</a></span>
            </div>
            <div class="clear"></div>
            <div class="content">
              One morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin
            </div>
          </div>
          <div class="clear"></div>
        </li>
        <li>
          <div class="author">
            <div class="pic">
              <img class="" src="imgs/admin.jpg" />
            </div>
            <div class="name">
              <a href="#">一米</a>
            </div>
          </div>
          <div class="info">
            <div class="data">
              <span class="date">2011年07月19日</span><span class="action"><a href="#">回复</a> | <a href="#">引用</a></span>
            </div>
            <div class="clear"></div>
            <div class="content">
              One morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin
            </div>
          </div>
          <div class="clear"></div>
        </li>-->
        
      <!--</ul>-->
    </div>
    <div class="clear"></div>
    <!--<div class="inputarea">
      <label for="username"><input type="text" placeholder="昵称" required />昵称(必须)</label><br />
      <label for="email"><input type="email" placeholder="E-mail" required />电子邮箱(必须)</label><br />
      <label for="website"><input type="website" placeholder="网址" />网址</label><br />
      <textarea></textarea><br />
      <input class="submit" type="submit" value="发布(Ctrl+Enter)" />
    </div>-->
  </div>
  
  
  
  
  
  <div id="center">
    <div class="title">
    <?php if (have_posts()) : while (have_posts()) : the_post(); update_post_caches($posts); ?>
      <h2><?php the_title(); ?></h2>
    </div>
    <div class="content">
     <?php the_content(); ?>
    </div>
    <div class="under">
      <span class="time">时间：</span><span><?php the_time(__('F d', 'lighterblue')) ?></span><span class="categories">分类：</span><span><?php the_category(', '); ?><span class="tags">标签：</span><span><?php the_tags('', ', ', ''); ?></span>
    <?php endwhile; else : ?>
    <?php endif; ?>
    </div>
  </div>
</div>
<?php get_footer(); ?>