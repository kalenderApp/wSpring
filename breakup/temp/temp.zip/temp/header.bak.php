<!DOCTYPE html>
<html>
<head> 
<meta charset="<?php bloginfo('charset'); ?>" />
<title><?php bloginfo('name'); ?><?php wp_title(); ?></title> 
<?php 
	$options = get_option('analytics_options');
	$description = "";
	$keywords = "";
	if(is_home()) {
		$description = $options['description'];
		$keywords = $options['keywords'];
	}else if(is_single()) {
		$description = mb_strimwidth(strip_tags($post->post_content),1,200);//the_excerpt();
		$keywords = strip_tags(get_the_tag_list('', ', ', '')); 
	}
?>
<?php
	function ShowSeoDescription($strings) {
		if ($strings) {
			echo $strings;
		}else echo bloginfo('name');
	}
	function ShowSeoKeywords($strings) {
		if ($strings) {
			echo $strings;
		}else echo bloginfo('description');
	}
?>
<meta name="description" content="<?php ShowSeoDescription($description); ?>" />
<meta name="keywords" content="<?php ShowSeoKeywords($keywords); ?>" />
<?php rsd_link(); ?>
<?php wlwmanifest_link(); ?>
<link rel="alternate" type="application/rss+xml" title="<?php _e('RSS 2.0 - all posts', 'iw'); ?>" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/rss+xml" title="<?php _e('RSS 2.0 - all comments', 'iw'); ?>" href="<?php bloginfo('comments_rss2_url'); ?>" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="all">
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
<!--[if lte IE 8]>
  <link rel="stylesheet" href="style/ie8.css" type="text/css" media="screen" />
  <script src="script/html5.js"></script>
  <script src="script/css3-mediaqueries.js"></script>
<![endif]-->
<!--[if lte IE 6]>
  <link rel="stylesheet" href="style/ie6.css" type="text/css" media="screen" />
  <script src="script/ie6.js"></script>
<![endif]-->
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel='index' title="<?php bloginfo('name'); ?>" href="<?php bloginfo('url'); ?>" />
</head>
<body>
<div id="tips"><span>请输入正确的页码</span></div>
<div class="color">
  <span class="one"></span><span class="two"></span><span class="three"></span><span class="four"></span>
</div>
<div id="header">
  <div class="nav_left"><?php previous_posts_link(__('', 'lighterblue')); ?></div>
	<div class="nav">
    <ul class="menu">
      <li id="active">
        <a href="<?php bloginfo('url'); ?>">首页</a>
      </li>
    <?php wp_list_categories('title_li=0&orderby=name&show_count=0&depth=-1'); ?>
      <!--<li id="active">
        <a href="#">首页</a>
      </li>
      <li>
        <a href="#">视频</a>
      </li>
      <li>
        <a href="#">音频</a>
      </li>
      <li>
        <a href="#">图片</a>
        <ul class="nav_child">
          <li>
            <a href="#">美女</a>
          </li>
          <li>
            <a href="#">帅哥</a>
          </li>
          <li>
            <a href="#">明星</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="#">链接</a>
      </li>
      <li>
        <a href="#">其他</a>
      </li>-->
    </ul>
    <?php 
					if($options['twitter']){
					 $twitter = $options['twitter'];	
					}else{
            $twitter = "#";  
          }
					if($options['gplus']){
						$gplus = $options['gplus'];
					}else{
            $gplus = "#";  
          }
		?>
		<!-- 获取选项 -->
    <ul class="right">
      <li class="rss">
        <a href="<?php bloginfo('rss2_url'); ?>"></a>
      </li>
      <li class="twitter">
        <a href="https://twitter.com/<?php echo $twitter; ?>" target= "_blank"></a>
      </li>
      <li class="gplus">
        <a href="https://plus.google.com/<?php echo $gplus; ?>" target= "_blank"></a>
      </li>
    </ul>
  </div>
  <div class="nav_right"><?php next_posts_link(__('', 'lighterblue')); ?></div>
</div>